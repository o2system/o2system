<?php

namespace Haha\Controllers;

class Bah extends \App\Http\AccessControl\Controllers\AuthorizedController
{
    public function index()
    {
        print_out('Here');
    }
}
